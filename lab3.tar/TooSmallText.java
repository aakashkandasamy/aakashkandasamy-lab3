public class TooSmallText extends Exception {
    public TooSmallText(String message) {
        super(message);
    }
}